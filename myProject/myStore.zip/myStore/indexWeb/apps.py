from django.apps import AppConfig


class IndexwebConfig(AppConfig):
    name = 'indexWeb'
